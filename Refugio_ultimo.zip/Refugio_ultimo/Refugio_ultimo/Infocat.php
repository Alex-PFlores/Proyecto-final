<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/Info.css">
    <title>Beneficios de Adoptar un Gato</title>
</head>
<body>

<div class="header">
    <h1>Beneficios de Adoptar un Gato</h1>
</div>

<div class="contenedor">
    <h2>¿Por qué adoptar un gato?</h2>
    <p>Adoptar un gato trae numerosos beneficios tanto para el animal como para el adoptante. Aquí te mencionamos algunos de ellos:</p>
    <ul>
        <li><strong>Compañía:</strong> Los gatos son excelentes compañeros y pueden proporcionar una gran cantidad de amor y atención.</li>
        <li><strong>Reducción del Estrés:</strong> Interactuar con un gato puede reducir los niveles de estrés y ansiedad.</li>
        <li><strong>Beneficios para la Salud:</strong> Tener un gato puede ayudar a disminuir la presión arterial y mejorar la salud cardiovascular.</li>
        <li><strong>Salvación de una Vida:</strong> Adoptar de un refugio da una segunda oportunidad a un animal que realmente lo necesita.</li>
        <li><strong>Responsabilidad:</strong> Cuidar de un gato puede enseñar valiosas lecciones de responsabilidad y cuidado.</li>
        <li><strong>Interacción Social:</strong> Los gatos pueden mejorar tu vida social, ya que muchas personas se sienten atraídas por los animales y disfrutan hablando de ellos.</li>
    </ul>

    <h2>Video: Beneficios de Adoptar un Gatito</h2>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/ce0LPDPV5NE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

    <button onclick="window.location.href='index.php'" class="boton-regresar">Regresar a la página principal</button>
</div>

<div class="footer">
    <p>© 2025 Centro de Adopción de Gatitos. Todos los derechos reservados.</p>
</div>

</body>
</html>
