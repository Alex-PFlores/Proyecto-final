-- Base de datos: `refugio`

--tabla `contactos`
--

CREATE TABLE `contactos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mensaje` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Datos para la tabla `contactos`
--

INSERT INTO `contactos` (`id`, `nombre`, `email`, `mensaje`, `fecha`) VALUES
(1, 'Julia', 'victorpalacios456@hotmail.com', 'Quisiera saber si tienen mas gatos disponibles', '2025-06-12 03:54:27');

---------------------------------------------------------


-- tabla `gatitos`
--

CREATE TABLE `gatitos` (
  `id` int(11) NOT NULL,
  `imagen` varchar(500) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `edad` varchar(50) NOT NULL,
  `raza` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- datos para la tabla `gatitos`
--

INSERT INTO `gatitos` (`id`, `imagen`, `nombre`, `edad`, `raza`) VALUES
(1, 'imagenes_gatitos/1750041238_gato-173700-1024x576.jpeg', 'Francis', '1 año', 'Atrigado'),
(2, 'https://puppis.blog/articulo/como-cuidar-a-un-gato', 'Puppi', '2 Meses', 'Naranja'),
(3, 'uploads/1750043379_abc-cuidado-de-los-gatos-min.webp', 'Puppi', '2 Meses', 'Naranja'),
(4, 'uploads/1750162650_gatitos_1f740045_230522123911_1000x667.jpg', 'Eli y Archie', '2 meses', 'Mestizo');

---------------------------------------------------------


-- tabla `registro`
--

CREATE TABLE `registro` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `rol` varchar(20) DEFAULT 'Usuario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- datos para la tabla `registro`
--

INSERT INTO `registro` (`id`, `nombre`, `usuario`, `correo`, `numero`, `contraseña`, `rol`) VALUES
(1, 'VictorP', 'ArkhamS117', 'victorpalacios456@hotmail.com', '5631377322', '$2y$10$O76KUT1upMyD1z91Awiuxu31D71An4buy55.0Xxz4GTDzxyRPDCbG', 'Administrador'),
(2, 'Julia', 'JL12', 'lol@gmail.com', '549901', '$2y$10$gIcpcYl1Tav.7Hu/nYny0uXE3ZAALfDnZa6PzqOXP.orWXwHiUxAW', 'Usuario'),
(3, 'Ernestoq', 'Ern123', 'pqwe@gmail.com', '4218231', '$2y$10$dk22etqtqIqeak1rFgtbm.DnLxkEJnGAzk7qYk/Lb9vZ/tm3rMY3K', 'Usuario'),
(4, 'Mariana', 'Mar001', 'sfjw@gmail.com', '55400302', '$2y$10$iHi8O7ePL7yu74N/QFF.AO.tceT49Qp2FqN6aGl./masJcYCjya/K', 'Empleado'),
(5, 'Elizabeth', 'Eli123', 'victorpalacios456@hotmail.com', '5631377322', '$2y$10$yShk6mG5a7k2xQoxq8oUZORnSFUy/7x7TysEFynI8NusPLJFoXMKG', 'Administrador'),
(6, 'Saul', 'Sau1234', 'victorpalacios456@hotmail.com', '5631377322', '$2y$10$EemeQ.dUrKZ6lFyKL4KpQecbRFo9W6VN3sflY0db.uoTb7je2Q90O', 'Empleado'),
(7, 'Barnie', 'Bar123', 'victorpalacios456@hotmail.com', '5631377322', '$2y$10$4wZnSSdX00Kh3Hz7MXmq2e2BhhfTX0G/CV53s4Y3lfnJgsAczQAsS', 'Usuario');

---------------------------------------------------------


--tabla `solicitudes_adopcion`
--

CREATE TABLE `solicitudes_adopcion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `experiencia` text NOT NULL,
  `gastos` tinyint(1) NOT NULL,
  `atencion` varchar(255) NOT NULL,
  `horario` varchar(100) NOT NULL,
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- datos para la tabla `solicitudes_adopcion`
--

INSERT INTO `solicitudes_adopcion` (`id`, `nombre`, `apellido`, `email`, `telefono`, `direccion`, `experiencia`, `gastos`, `atencion`, `horario`, `fecha_solicitud`) VALUES
(4, 'Victor', 'Jacobo', 'victorpalacios456@hotmail.com', '542346', 'Cale falsa 123', '3 años', 1, 'Hermano', '7AM-9PM', '2025-06-12 03:41:46'),
(5, 'Victor', 'Jacobo', 'victorpalacios456@hotmail.com', '542346', 'Cale falsa 123', '2 años', 1, 'Hermano', '7AM-9PM', '2025-06-12 03:42:07'),
(6, 'Victor', 'Jacobo', 'victorpalacios456@hotmail.com', '542346', 'Cale falsa 123', '2 años', 1, 'Hermano', '7AM-9PM', '2025-06-12 03:42:15'),
(7, 'Julia', 'Jacobo', 'victorpalacios456@hotmail.com', '542346', 'Cale falsa 123', '1 año con 3 gatos', 1, 'Hermano', '7AM-9PM', '2025-06-12 03:42:54');


-- Índices para tablas volcadas
--

--
-- Indices de la tabla `contactos`
--
ALTER TABLE `contactos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `gatitos`
--
ALTER TABLE `gatitos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `solicitudes_adopcion`
--
ALTER TABLE `solicitudes_adopcion`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `contactos`
--
ALTER TABLE `contactos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `gatitos`
--
ALTER TABLE `gatitos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `registro`
--
ALTER TABLE `registro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `solicitudes_adopcion`
--
ALTER TABLE `solicitudes_adopcion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;
