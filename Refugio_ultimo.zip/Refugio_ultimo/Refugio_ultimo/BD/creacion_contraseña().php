<?php
$password = "empleado123";
$hash = password_hash($password, PASSWORD_DEFAULT);
echo $hash;
?>

<?php
$password = "administrador123";
$hash = password_hash($password, PASSWORD_DEFAULT);
echo $hash;
?>

<?php
$password = "usuario123";
$hash = password_hash($password, PASSWORD_DEFAULT);
echo $hash;
?>



INGRESAR desde localhost para crear el cifrado de cualquiers de estos dos usuarios.
Posterior, pegar este codigo con el nuevo hash (editarlo segun el acceso):

INSERT INTO registro (nombre, usuario, correo, numero, contraseña, rol)
VALUES (
    'Administrador General',
    'admin',
    'admin@refugio.com',
    '1234567890',
    'Tu hash va pegado aquí', -- Contraseña: admin123
    'Administrador'
);
