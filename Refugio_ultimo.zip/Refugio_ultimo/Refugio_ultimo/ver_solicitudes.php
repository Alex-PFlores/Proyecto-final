<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Administrador') {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "refugio";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

// Eliminar solicitud si se envió el formulario
if (isset($_POST['eliminar'])) {
    $id = $_POST['id'];
    $conn->query("DELETE FROM solicitudes_adopcion WHERE id = $id");
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Solicitudes de Adopción</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="text-center mb-4">Solicitudes de Adopción</h2>
    <a href="admin_panel.php" class="btn btn-secondary mb-3">Volver al Panel</a>
    <div class="table-responsive">
        <table class="table table-bordered table-hover bg-white">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Experiencia</th>
                    <th>Atención</th>
                    <th>Horario</th>
                    <th>Fecha Solicitud</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM solicitudes_adopcion";
                $result = $conn->query($sql);

                if ($result->num_rows > 0):
                    while ($row = $result->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['nombre'] ?></td>
                        <td><?= $row['apellido'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['telefono'] ?></td>
                        <td><?= $row['direccion'] ?></td>
                        <td><?= $row['experiencia'] ?></td>
                        <td><?= $row['atencion'] ?></td>
                        <td><?= $row['horario'] ?></td>
                        <td><?= $row['fecha_solicitud'] ?></td>
                        <td>
                            <form method="POST" onsubmit="return confirm('¿Estás seguro de eliminar esta solicitud?');">
                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                <button type="submit" name="eliminar" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php
                    endwhile;
                else:
                    echo "<tr><td colspan='11' class='text-center'>No hay solicitudes registradas.</td></tr>";
                endif;
                ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>