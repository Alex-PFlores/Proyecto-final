<?php
session_start();

// Redirige si ya hay sesión
if (isset($_SESSION['usuario']) && isset($_SESSION['rol'])) {
    $redireccion = match ($_SESSION['rol']) {
        "Administrador" => "admin_panel.php",
        "Empleado" => "panel_trabajador.php",
        default => "panel_usuario.php", // Usuario común
    };
    header("Location: $redireccion");
    exit;
} else {
    // Si no hay sesión, va al login
    header("Location: login.php");
    exit;
}
?>
