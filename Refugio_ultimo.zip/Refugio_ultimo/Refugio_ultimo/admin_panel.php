<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Administrador') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-3">
    <!-- Botón de ayuda -->
    <a href="INFO.php?origen=admin" class="btn btn-outline-info me-3" title="Ayuda" style="font-size: 20px;">?</a>

    <!-- Título -->
    <a class="navbar-brand" href="#">Panel Administrador</a>

    <!-- Botón responsive -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menú derecho -->
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
            </li>
        </ul>
    </div>
</nav>

<!-- Contenido -->
<div class="container mt-4">
    <div class="alert alert-primary" role="alert">
        Bienvenido al panel de administrador. Usa el menú para navegar entre las opciones.
    </div>

    <div class="list-group">
        <a href="editar_usuarios.php" class="list-group-item list-group-item-action">Editar Usuarios</a>
        <a href="ver_solicitudes.php" class="list-group-item list-group-item-action">Solicitudes de Adopción</a>
        <a href="ver_mensajes.php" class="list-group-item list-group-item-action">Mensajes</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
