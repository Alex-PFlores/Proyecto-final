<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Empleado') {
    header("Location: login.php");
    exit();
}

$conexion = new mysqli("localhost", "root", "", "refugio");
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Eliminar solicitud
if (isset($_GET['eliminar_solicitud'])) {
    $id = $_GET['eliminar_solicitud'];
    $stmt = $conexion->prepare("DELETE FROM solicitudes_adopcion WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: panel_trabajador.php#solicitudes");
    exit();
}

// Eliminar mensaje
if (isset($_GET['eliminar_mensaje'])) {
    $id = $_GET['eliminar_mensaje'];
    $stmt = $conexion->prepare("DELETE FROM contactos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: panel_trabajador.php#mensajes");
    exit();
}

// Eliminar gatito
if (isset($_GET['eliminar_gatito'])) {
    $id = $_GET['eliminar_gatito'];
    $stmt = $conexion->prepare("DELETE FROM gatitos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: panel_trabajador.php#listado");
    exit();
}

// Editar gatito
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['editar_id'])) {
    $id = $_POST['editar_id'];
    $nombre = $_POST['editar_nombre'];
    $edad = $_POST['editar_edad'];
    $raza = $_POST['editar_raza'];

    $stmt = $conexion->prepare("UPDATE gatitos SET nombre=?, edad=?, raza=? WHERE id=?");
    $stmt->bind_param("sssi", $nombre, $edad, $raza, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: panel_trabajador.php#listado");
    exit();
}

// Agregar gatito
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nombre'], $_POST['edad'], $_POST['raza']) && isset($_FILES['imagen'])) {
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $raza = $_POST['raza'];

    if ($_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $nombreTemporal = $_FILES['imagen']['tmp_name'];
        $nombreOriginal = basename($_FILES['imagen']['name']);
        $rutaDestino = "gatitos_img/" . uniqid() . "_" . $nombreOriginal;

        $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif'];

       // $tipoArchivo = mime_content_type($nombreTemporal);
       $finfo = finfo_open(FILEINFO_MIME_TYPE);
       $tipoArchivo = finfo_file($finfo, $nombreTemporal);
       finfo_close($finfo);


        if (!in_array($tipoArchivo, $tiposPermitidos)) {
            echo "<div class='alert alert-danger'>Tipo de imagen no permitido. Solo JPG, PNG o GIF.</div>";
        } elseif (move_uploaded_file($nombreTemporal, $rutaDestino)) {
            $stmt = $conexion->prepare("INSERT INTO gatitos (nombre, edad, raza, imagen) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nombre, $edad, $raza, $rutaDestino);
            $stmt->execute();
            $stmt->close();
            header("Location: panel_trabajador.php#listado");
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error al mover la imagen al servidor.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Error al subir la imagen. Código: " . $_FILES['imagen']['error'] . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Trabajador</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        .seccion-panel { display: none; }
        .nav-link.active {
            background-color: #ffc107;
            border-radius: 5px;
            font-weight: bold;
            color: #000 !important;
        }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-warning mb-4">
        <div class="container-fluid">
            <a href="INFO.php?origen=empleado" class="btn btn-dark me-2" title="Ayuda">?</a>
            <a class="navbar-brand fw-bold text-dark" href="#">Panel del Trabajador</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link text-dark" href="#" onclick="mostrarSeccion('solicitudes', this)">Solicitudes</a></li>
                    <li class="nav-item"><a class="nav-link text-dark" href="#" onclick="mostrarSeccion('mensajes', this)">Mensajes</a></li>
                    <li class="nav-item"><a class="nav-link text-dark" href="#" onclick="mostrarSeccion('gatitos', this)">Agregar Gatito</a></li>
                    <li class="nav-item"><a class="nav-link text-dark" href="#" onclick="mostrarSeccion('listado', this)">Ver Gatitos</a></li>
                </ul>
                <a href="logout.php" class="btn btn-outline-dark">Cerrar sesión</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Sección Solicitudes -->
        <section id="solicitudes" class="seccion-panel mb-5">
            <h3>Solicitudes de Adopción</h3>
            <?php
            $resultado = $conexion->query("SELECT * FROM solicitudes_adopcion");
            while ($fila = $resultado->fetch_assoc()) {
                echo "<div class='card mb-3'><div class='card-body'>";
                echo "<h5 class='card-title'>{$fila['nombre']} {$fila['apellido']}</h5>";
                echo "<p class='card-text'><strong>Teléfono:</strong> {$fila['telefono']}<br>
                      <strong>Email:</strong> {$fila['email']}<br>
                      <strong>Dirección:</strong> {$fila['direccion']}<br>
                      <strong>Experiencia:</strong> {$fila['experiencia']}<br>
                      <strong>Atención:</strong> {$fila['atencion']}<br>
                      <strong>Horario:</strong> {$fila['horario']}<br>
                      <strong>Fecha:</strong> {$fila['fecha_solicitud']}</p>";
                echo "<a href='?eliminar_solicitud={$fila['id']}' class='btn btn-sm btn-danger'>Eliminar</a>";
                echo "</div></div>";
            }
            ?>
        </section>

        <!-- Sección Mensajes -->
        <section id="mensajes" class="seccion-panel mb-5">
            <h3>Mensajes de Contacto</h3>
            <?php
            $resultado = $conexion->query("SELECT * FROM contactos");
            while ($fila = $resultado->fetch_assoc()) {
                echo "<div class='card mb-3'><div class='card-body'>";
                echo "<h5 class='card-title'>{$fila['nombre']}</h5>";
                echo "<p class='card-text'><strong>Email:</strong> {$fila['email']}<br>
                      <strong>Mensaje:</strong> {$fila['mensaje']}<br>
                      <strong>Fecha:</strong> {$fila['fecha']}</p>";
                echo "<a href='?eliminar_mensaje={$fila['id']}' class='btn btn-sm btn-danger'>Eliminar</a>";
                echo "</div></div>";
            }
            ?>
        </section>

        <!-- Sección Agregar Gatito -->
        <section id="gatitos" class="seccion-panel mb-5">
            <h3>Agregar Gatito</h3>
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Nombre</label>
                    <input type="text" name="nombre" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Edad</label>
                    <input type="text" name="edad" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Raza</label>
                    <input type="text" name="raza" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Imagen del Gatito</label>
                    <input type="file" name="imagen" class="form-control" accept="image/*" required>
                </div>
                <button type="submit" class="btn btn-success">Agregar Gatito</button>
            </form>
        </section>

        <!-- Sección Ver Gatitos -->
        <section id="listado" class="seccion-panel mb-5">
            <h3>Gatitos Registrados</h3>
            <div class="row">
                <?php
                $resultado = $conexion->query("SELECT * FROM gatitos");
                while ($fila = $resultado->fetch_assoc()) {
                    echo "<div class='col-md-4 mb-4'>";
                    echo "<div class='card'>";
                    echo "<img src='{$fila['imagen']}' class='card-img-top' style='height: 200px; object-fit: cover;'>";
                    echo "<div class='card-body'>";
                    echo "<h5 class='card-title'>{$fila['nombre']}</h5>";
                    echo "<p class='card-text'><strong>Edad:</strong> {$fila['edad']}<br><strong>Raza:</strong> {$fila['raza']}</p>";
                    echo "<form method='POST' class='mb-2'>
                            <input type='hidden' name='editar_id' value='{$fila['id']}'>
                            <input type='text' name='editar_nombre' value='{$fila['nombre']}' class='form-control form-control-sm mb-1' required>
                            <input type='text' name='editar_edad' value='{$fila['edad']}' class='form-control form-control-sm mb-1' required>
                            <input type='text' name='editar_raza' value='{$fila['raza']}' class='form-control form-control-sm mb-1' required>
                            <button type='submit' class='btn btn-primary btn-sm'>Guardar Cambios</button>
                          </form>";
                    echo "<a href='?eliminar_gatito={$fila['id']}' class='btn btn-danger btn-sm'>Eliminar</a>";
                    echo "</div></div></div>";
                }
                ?>
            </div>
        </section>
    </div>

    <script>
        function ocultarTodo() {
            document.querySelectorAll('.seccion-panel').forEach(sec => sec.style.display = 'none');
            document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
        }

        function mostrarSeccion(id, link = null) {
            ocultarTodo();
            document.getElementById(id).style.display = 'block';
            if (link) link.classList.add('active');
            window.location.hash = id;
        }

        window.onload = function () {
            const hash = window.location.hash.substring(1);
            const seccion = hash && document.getElementById(hash) ? hash : null;
            if (seccion) {
                const link = Array.from(document.querySelectorAll('.nav-link')).find(l => l.textContent.toLowerCase().includes(seccion));
                mostrarSeccion(seccion, link);
            }
        };
    </script>
</body>
</html>
