<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';
require('fpdf/fpdf.php');

// Inicia el buffer de salida
ob_start();

// Conexión DB
$conexion = new mysqli("localhost", "root", "", "refugio");
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Datos del formulario
$nombre = $_POST['nombre'] ?? '';
$apellido = $_POST['apellido'] ?? '';
$email = $_POST['email'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$direccion = $_POST['direccion'] ?? '';
$experiencia = $_POST['experiencia'] ?? '';
$gastos = ($_POST['gastos'] ?? '') == 1 ? "Sí" : "No";
$atencion = $_POST['atencion'] ?? '';
$horario = $_POST['horario'] ?? '';
$gatito_id = $_POST['gatito_id'] ?? '';

// Obtener info del gatito
$nombre_gato = $edad = $raza = '';
if ($gatito_id !== '') {
    $stmt = $conexion->prepare("SELECT nombre, edad, raza FROM gatitos WHERE id = ?");
    $stmt->bind_param("i", $gatito_id);
    $stmt->execute();
    $stmt->bind_result($nombre_gato, $edad, $raza);
    $stmt->fetch();
    $stmt->close();
}

// Generar PDF
/*$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,"Formulario de Adopción",0,1,'C');
$pdf->Ln(10);
$pdf->SetFont('Arial','',12);
$pdf->MultiCell(0,10,"Nombre: $nombre $apellido\nEmail: $email\nTeléfono: $telefono\nDirección: $direccion\nExperiencia: $experiencia\nPuede cubrir gastos: $gastos\nAtención: $atencion\nHorario: $horario\n\nGatito: $nombre_gato\nEdad: $edad\nRaza: $raza");*/
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10, utf8_decode("Formulario de Adopción"), 0, 1, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial','',12);

$contenido = "Nombre: $nombre $apellido\n";
$contenido .= "Email: $email\n";
$contenido .= "Teléfono: $telefono\n";
$contenido .= "Dirección: $direccion\n";
$contenido .= "Experiencia: $experiencia\n";
$contenido .= "Puede cubrir gastos: $gastos\n";
$contenido .= "Atención: $atencion\n";
$contenido .= "Horario: $horario\n\n";
$contenido .= "Gatito: $nombre_gato\n";
$contenido .= "Edad: $edad\n";
$contenido .= "Raza: $raza";

$pdf->MultiCell(0, 10, utf8_decode($contenido));



$fileName = "formulario_adopcion_" . time() . ".pdf";
$filePath = __DIR__ . "/pdfs/" . $fileName;
$pdf->Output("F", $filePath);

//$filePath = "formulario_adopcion_" . time() . ".pdf";
//$pdf->Output("F", $filePath); // Guardar el PDF

// Enviar correo
$mail = new PHPMailer(true);
$success = false;
$errorMsg = '';

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'alexisleon202@gmail.com'; // <- TU GMAIL
    $mail->Password = 'onig tqri vrgm ngep';   // <- CONTRASEÑA DE APLICACIÓN
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('TU_CORREO@gmail.com', 'Refugio de Gatitos');
    $mail->addAddress($email, "$nombre $apellido");
    $mail->Subject = 'Formulario de Adopción';
    $mail->Body = 'Gracias por adoptar un gatito. Adjuntamos tu formulario en PDF.';
    $mail->addAttachment($filePath);

    $mail->send();

    $success = true;
} catch (Exception $e) {
    $errorMsg = $mail->ErrorInfo;
}

/* Mostrar el PDF en navegador

echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
if ($success) {
    echo "<script>
        Swal.fire({
            icon: 'success',
            title: '¡PDF generado!',
            text: 'El archivo PDF fue enviado a tu correo correctamente.',
        }).then(() => {
            window.open('pdfs/$fileName', '_blank');

        });
    </script>";
} else {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Error al enviar el correo',
            text: 'No se pudo enviar el PDF al correo proporcionado. Puedes visualizarlo directamente.',
        }).then(() => {
            window.open('pdfs/$fileName', '_blank');

        });
    </script>";
}*/
echo "
<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
</head>
<body>
<script>
Swal.fire({
    icon: 'success',
    title: '¡Formulario enviado!',
    text: 'Se ha enviado el formulario por correo electrónico. Favor de presentarlo en nuestro Refugio para poder continuar con su adopción.',
    confirmButtonText: 'Regresar al catálogo',
    allowOutsideClick: false,
    allowEscapeKey: false
}).then(() => {
    window.location.href = 'catalogo.php';
});
</script>
</body>
</html>";


?>
