<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centro de Adopción de Gatitos</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Tus estilos -->
    <link rel="stylesheet" href="CSS/Index.css">
    <link rel="stylesheet" href="CSS/carrusel.css">
</head>
<body>

    <!-- Encabezado -->
    <div class="header d-flex justify-content-between align-items-center px-3 py-2 position-relative">
        <!-- Botón de ayuda -->
        <a href="INFO.php?origen=index" class="btn btn-outline-primary position-absolute start-0 top-50 translate-middle-y ms-3" title="Ayuda" style="font-size: 20px; font-weight: bold;">?</a>

        <!-- Título centrado -->
        <h1 class="text-center w-100 m-0">Centro de Adopción de Gatitos</h1>

        <!-- Botones a la derecha -->
        <div class="menu-right d-flex gap-2">
            <button onclick="toggleDarkMode()" class="btn btn-secondary">Modo Oscuro</button>
            <button onclick="logOut()" class="btn btn-danger">Log Out</button>
        </div>
    </div>

    <!-- Menú principal -->
    <div class="menu">
        <ul>
            <li><a href="Catalogo.php">Gatitos</a></li>
            <li><a href="Voluntariado.php">Voluntariado</a></li>
            <li><a href="Contacto.php">Contacto</a></li>
        </ul>
    </div>

    <!-- Contenido principal -->
    <div class="main-content">
        <h1>Bienvenido al Centro de Adopción</h1>
        <p>Aquí encontrarás gatitos listos para encontrar un hogar. Nuestro objetivo es ayudar a estos animales a encontrar familias amorosas. ¡Descubre más sobre el proceso de adopción y los gatitos disponibles!</p>

        <!-- Carrusel de imágenes -->
        <div class="carousel-container">
            <div class="carousel-images">
                <img src="IMAGENES/gatitos 1.png" alt="Gatito 1">
                <img src="IMAGENES/gatitos 2.png" alt="Gatito 2">
                <img src="IMAGENES/gatitos 3.png" alt="Gatito 3">
                <img src="IMAGENES/gatitos 4.jpeg" alt="Gatito 4">
                <img src="IMAGENES/gatitos 5.jpeg" alt="Gatito 5">
                <img src="IMAGENES/gatitos 6.jpg" alt="Gatito 6">
                <img src="IMAGENES/gatitos 7.jpg" alt="Gatito 7">
                <img src="IMAGENES/gatitos 8.jpg" alt="Gatito 8">
                <img src="IMAGENES/gatitos 9.jpeg" alt="Gatito 9">
                <img src="IMAGENES/gatitos 10.jpg" alt="Gatito 10">
            </div>
            <div class="carousel-buttons">
                <button class="carousel-button" onclick="moveSlide(-1)">&#10094;</button>
                <button class="carousel-button" onclick="moveSlide(1)">&#10095;</button>
            </div>
        </div>
    </div>

    <!-- Aside lateral con info -->
    <div class="aside">
        <h2>¿Tienes preguntas?</h2>
        <p>Contáctanos para más información sobre el proceso de adopción.</p>
        <h2>Ubicación</h2>
        <p>Estamos ubicados en: Xochicalco 95, Narvarte Poniente, Benito Juárez, 03020 Ciudad de México, CDMX.</p>
        <h2>Cómo llegar</h2>
        <p>Consulta nuestro mapa.</p>

        <div class="map-container">
            <img src="IMAGENES/mapa.PNG" alt="Mapa de la ubicación" width="100%" style="border-radius: 10px;">
        </div>
    </div>

    <!-- Pie de página -->
    <div class="footer">
        <p>© 2025 Centro de Adopción de Gatitos. Todos los derechos reservados. UPIICSA</p>
    </div>

    <!-- Scripts -->
    <script>
        function toggleDarkMode() {
            const body = document.body;
            body.style.backgroundColor = body.style.backgroundColor === "black" ? "#f7f7f7" : "black";
            body.style.color = body.style.color === "white" ? "black" : "white";
        }

        function logOut() {
            window.location.href = "logout.php";
        }

        const images = document.querySelectorAll('.carousel-images img');
        const carouselImages = document.querySelector('.carousel-images');
        const visibleCount = 3;
        const totalImages = images.length;

        function getImageWidth() {
            const style = getComputedStyle(images[0]);
            const width = images[0].clientWidth;
            const marginRight = parseInt(style.marginRight) || 0;
            return width + marginRight;
        }

        let currentIndex = 0;
        let imageWidth = getImageWidth();

        function updateSlidePosition() {
            const offset = currentIndex * imageWidth;
            carouselImages.style.transform = `translateX(-${offset}px)`;
        }

        function moveSlide(direction) {
            currentIndex += direction;
            if (currentIndex > totalImages - visibleCount) {
                currentIndex = 0;
            } else if (currentIndex < 0) {
                currentIndex = totalImages - visibleCount;
            }
            updateSlidePosition();
        }

        window.addEventListener('resize', () => {
            imageWidth = getImageWidth();
            updateSlidePosition();
        });

        updateSlidePosition();
        setInterval(() => {
            moveSlide(1);
        }, 5000);
    </script>

</body>
</html>
