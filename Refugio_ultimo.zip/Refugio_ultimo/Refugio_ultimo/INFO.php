<?php
$origen = $_GET['origen'] ?? 'index';
$url = 'index.php';
if ($origen === 'admin') $url = 'admin_panel.php';
if ($origen === 'empleado') $url = 'panel_trabajador.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Información del Sistema</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <!-- Encabezado -->
    <div class="container mt-4">
        <h1 class="text-center mb-4">¿Cómo funciona el sistema?</h1>

        <!-- Apartado: Usuario -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                Usuario
            </div>
            <div class="card-body">
                <ul>
                    <li>Puede <strong>ver el catálogo de gatitos</strong> disponibles para adopción.</li>
                    <li>Al dar clic en <em>"Adoptar"</em>, accede a un <strong>formulario de adopción</strong>.</li>
                    <li>Llena sus datos y envía la solicitud. Al enviarla se <strong>genera un PDF</strong> con los datos del adoptante y del gatito seleccionado.</li>
                    <li>Puede ver otras páginas como <strong>Voluntariado</strong> y <strong>Contacto</strong>.</li>
                    <li>Puede activar el <strong>modo oscuro</strong> y cerrar sesión desde el menú.</li>
                </ul>
            </div>
        </div>

        <!-- Botón para volver -->
        <div class="text-center">
            <a href="<?php echo $url; ?>" class="btn btn-secondary">Volver al inicio</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
