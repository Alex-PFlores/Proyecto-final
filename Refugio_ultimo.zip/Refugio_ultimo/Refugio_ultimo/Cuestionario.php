<?php

session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'Usuario') {
    header("Location: login.php");
    exit();
}

$conexion = new mysqli("localhost", "root", "", "refugio");
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$gatito = null;
if (isset($_GET['id'])) {
    $gatito_id = intval($_GET['id']);
    $stmt = $conexion->prepare("SELECT * FROM gatitos WHERE id = ?");
    $stmt->bind_param("i", $gatito_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $gatito = $resultado->fetch_assoc();
    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir datos del formulario y del gatito (ocultos)
    $nombre      = trim($_POST['nombre']);
    $apellido    = trim($_POST['apellido']);
    $email       = trim($_POST['email']);
    $telefono    = trim($_POST['telefono']);
    $direccion   = trim($_POST['direccion']);
    $experiencia = trim($_POST['experiencia']);
    $gastos      = ($_POST['gastos'] === "si") ? 1 : 0;
    $atencion    = trim($_POST['atencion']);
    $horario     = trim($_POST['horario']);
    $gatito_id   = intval($_POST['gatito_id']);
    $imagen = $_POST['imagen'] ?? '';

    //$imagen      = $_POST['imagen'];
    $nombre_gato = $_POST['nombre_gato'];
    $edad        = $_POST['edad'];
    $raza        = $_POST['raza'];

    // Validación simple
    if (
        empty($nombre) || empty($apellido) || empty($email) || empty($telefono) ||
        empty($direccion) || empty($experiencia) || empty($atencion) || empty($horario)
    ) {
        echo "<script>alert('Por favor, completa todos los campos.'); window.history.back();</script>";
        exit;
    }

    // Guardar solicitud
    $stmt = $conexion->prepare("INSERT INTO solicitudes_adopcion (nombre, apellido, email, telefono, direccion, experiencia, gastos, atencion, horario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssiss", $nombre, $apellido, $email, $telefono, $direccion, $experiencia, $gastos, $atencion, $horario);
    if ($stmt->execute()) {
        // Redirigir a generar_pdf.php enviando TODO por POST (usando form oculto)
        echo "<form id='redirigirPDF' action='generar_pdf.php' method='POST' style='display:none;'>
                <input type='hidden' name='nombre' value='".htmlspecialchars($nombre, ENT_QUOTES)."'>
                <input type='hidden' name='apellido' value='".htmlspecialchars($apellido, ENT_QUOTES)."'>
                <input type='hidden' name='email' value='".htmlspecialchars($email, ENT_QUOTES)."'>
                <input type='hidden' name='telefono' value='".htmlspecialchars($telefono, ENT_QUOTES)."'>
                <input type='hidden' name='direccion' value='".htmlspecialchars($direccion, ENT_QUOTES)."'>
                <input type='hidden' name='experiencia' value='".htmlspecialchars($experiencia, ENT_QUOTES)."'>
                <input type='hidden' name='gastos' value='".htmlspecialchars($gastos, ENT_QUOTES)."'>
                <input type='hidden' name='atencion' value='".htmlspecialchars($atencion, ENT_QUOTES)."'>
                <input type='hidden' name='horario' value='".htmlspecialchars($horario, ENT_QUOTES)."'>
                <input type='hidden' name='gatito_id' value='".htmlspecialchars($gatito_id, ENT_QUOTES)."'>
                
                <input type='hidden' name='nombre_gato' value='".htmlspecialchars($nombre_gato, ENT_QUOTES)."'>
                <input type='hidden' name='edad' value='".htmlspecialchars($edad, ENT_QUOTES)."'>
                <input type='hidden' name='raza' value='".htmlspecialchars($raza, ENT_QUOTES)."'>
              </form>
              <script>document.getElementById('redirigirPDF').submit();</script>";
        exit;
    } else {
        echo "<script>alert('Error al guardar la solicitud.'); window.history.back();</script>";
    }
    $stmt->close();
    $conexion->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Formulario de Adopción de Gatos</title>
    <link rel="stylesheet" href="CSS/Cuestionario.css" />
    <script>
        function validarFormulario(event) {
            event.preventDefault();
            const campos = ['nombre', 'apellido', 'email', 'telefono', 'direccion', 'experiencia', 'gastos', 'atencion', 'horario'];
            let valido = true;
            campos.forEach(id => {
                document.getElementById(id).style.borderColor = '#CCC';
                if (document.getElementById(id).value.trim() === "") {
                    document.getElementById(id).style.borderColor = 'red';
                    valido = false;
                }
            });
            if (!valido) {
                alert("Por favor, completa todos los campos.");
            } else {
                event.target.submit();
            }
        }
    </script>
</head>
<body>
<div class="contenedor">
    <h2>Formulario de Adopción de Gatos</h2>

    <?php if ($gatito): ?>
        <p><strong>Gatito seleccionado:</strong> <?php echo htmlspecialchars($gatito['nombre']); ?></p>
        <img src="gatitos_img/<?php echo htmlspecialchars($gatito['imagen']); ?>" alt="Gatito" style="max-width:150px;">
    <?php else: ?>
        <p>Gatito no encontrado.</p>
        <a href="catalogo.php">Volver al catálogo</a>
        <?php exit; ?>
    <?php endif; ?>

    <form action="" method="POST" onsubmit="validarFormulario(event)">
        <input type="hidden" name="gatito_id" value="<?php echo $gatito['id']; ?>">
        
        <?php
// Cargar datos del gatito seleccionado
if (isset($_GET['gatito_id'])) {
    $conexion = new mysqli("localhost", "root", "", "refugio");
    $gatito_id = intval($_GET['gatito_id']);
    $stmt = $conexion->prepare("SELECT nombre, edad, raza, imagen FROM gatitos WHERE id = ?");
    $stmt->bind_param("i", $gatito_id);
    $stmt->execute();
    $stmt->bind_result($nombre_gato, $edad_gato, $raza_gato, $imagen_gato);
    $stmt->fetch();
    $stmt->close();
    $conexion->close();
?>
    <input type="hidden" name="nombre_gato" value="<?php echo htmlspecialchars($nombre_gato, ENT_QUOTES); ?>">
    <input type="hidden" name="edad" value="<?php echo htmlspecialchars($edad_gato, ENT_QUOTES); ?>">
    <input type="hidden" name="raza" value="<?php echo htmlspecialchars($raza_gato, ENT_QUOTES); ?>">
<?php } ?>

        <input type="hidden" name="nombre_gato" value="<?php echo htmlspecialchars($gatito['nombre']); ?>">
        <input type="hidden" name="edad" value="<?php echo htmlspecialchars($gatito['edad']); ?>">
        <input type="hidden" name="raza" value="<?php echo htmlspecialchars($gatito['raza']); ?>">

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" />

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" />

        <label for="email">Correo electrónico:</label>
        <input type="email" id="email" name="email" />

        <label for="telefono">Teléfono:</label>
        <input type="tel" id="telefono" name="telefono" />

        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" />

        <label for="experiencia">Experiencia con gatos:</label>
        <textarea id="experiencia" name="experiencia"></textarea>

        <label for="gastos">¿Estás dispuesto a asumir los gastos mensuales de un gato?</label>
        <select id="gastos" name="gastos">
            <option value="">Seleccione una opción</option>
            <option value="si">Sí</option>
            <option value="no">No</option>
        </select>

        <label for="atencion">¿Quién se encargará del cuidado del gato cuando estés ausente?</label>
        <input type="text" id="atencion" name="atencion" />

        <label for="horario">Horario de trabajo:</label>
        <input type="text" id="horario" name="horario" />

        <button type="submit" class="boton">Enviar</button>
    </form>
</div>
</body>
</html>
